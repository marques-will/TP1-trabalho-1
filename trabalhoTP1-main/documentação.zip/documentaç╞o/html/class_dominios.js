var class_dominios =
[
    [ "getValor", "class_dominios.html#ac86d0cf047c11d1693d421ffc62480a6", null ],
    [ "setValor", "class_dominios.html#ac50f72c7293e9f869b1e0e22f13970ca", null ],
    [ "validar", "class_dominios.html#aaf14c90fbf97c6fdf8a661d7d853e73f", null ]
];