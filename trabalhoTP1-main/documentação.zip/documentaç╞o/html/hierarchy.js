var hierarchy =
[
    [ "Dominios", "class_dominios.html", [
      [ "Classe", "class_classe.html", null ],
      [ "Codigo", "class_codigo.html", null ],
      [ "Data", "class_data.html", null ],
      [ "Matricula", "class_matricula.html", null ],
      [ "Resultado", "class_resultado.html", null ],
      [ "Senha", "class_senha.html", null ],
      [ "Telefone", "class_telefone.html", null ],
      [ "Texto", "class_texto.html", null ]
    ] ],
    [ "Entidade", "class_entidade.html", [
      [ "CasoDeTeste", "class_caso_de_teste.html", null ],
      [ "Desenvolvedor", "class_desenvolvedor.html", null ]
    ] ],
    [ "TUDominios", "class_t_u_dominios.html", [
      [ "TUClasse", "class_t_u_classe.html", null ],
      [ "TUCodigo", "class_t_u_codigo.html", null ],
      [ "TUData", "class_t_u_data.html", null ],
      [ "TUMatricula", "class_t_u_matricula.html", null ],
      [ "TUResultado", "class_t_u_resultado.html", null ],
      [ "TUSenha", "class_t_u_senha.html", null ],
      [ "TUTelefone", "class_t_u_telefone.html", null ],
      [ "TUTexto", "class_t_u_texto.html", null ]
    ] ],
    [ "TUEntidades", "class_t_u_entidades.html", [
      [ "TUCasoDeTeste", "class_t_u_caso_de_teste.html", null ],
      [ "TUDesenvolvedor", "class_t_u_desenvolvedor.html", null ]
    ] ]
];