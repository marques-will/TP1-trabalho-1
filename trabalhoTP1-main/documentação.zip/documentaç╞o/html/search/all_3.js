var searchData=
[
  ['getacao_0',['getAcao',['../class_caso_de_teste.html#a04eb097ddba174c9db57b236592f7fe6',1,'CasoDeTeste']]],
  ['getcodigo_1',['getCodigo',['../class_caso_de_teste.html#a68775e83df5383fbf47615a4f7f6728c',1,'CasoDeTeste']]],
  ['getdata_2',['getData',['../class_caso_de_teste.html#a8d0ee22f5ee7825a570f14ff5a079751',1,'CasoDeTeste']]],
  ['getmatricula_3',['getMatricula',['../class_desenvolvedor.html#ae591c12a4bbd91d1c25f88cb06a147e8',1,'Desenvolvedor']]],
  ['getnome_4',['getNome',['../class_entidade.html#a697bc184b87d5ce01fe57e1aa317625f',1,'Entidade']]],
  ['getresposta_5',['getResposta',['../class_caso_de_teste.html#ac5d56ab43c281f8b335f1c3be49f32a8',1,'CasoDeTeste']]],
  ['getresultado_6',['getResultado',['../class_caso_de_teste.html#a43a464ac3101441ad19de4c47a21c89d',1,'CasoDeTeste']]],
  ['getsenha_7',['getSenha',['../class_desenvolvedor.html#aa6841a9369baf7440ae621f88c1fa5ad',1,'Desenvolvedor']]],
  ['gettelefone_8',['getTelefone',['../class_desenvolvedor.html#a2c86429c9422fb1c281e4ff7ed3e4fe8',1,'Desenvolvedor']]],
  ['getvalor_9',['getValor',['../class_dominios.html#ac86d0cf047c11d1693d421ffc62480a6',1,'Dominios']]]
];
