var class_entidade =
[
    [ "getNome", "class_entidade.html#a697bc184b87d5ce01fe57e1aa317625f", null ],
    [ "setNome", "class_entidade.html#addbfb55c75e014e7b384bf0ea0336861", null ]
];